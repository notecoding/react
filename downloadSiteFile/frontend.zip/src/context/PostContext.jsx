// 📁 src/context/PostContext.jsx
import React, { createContext, useState, useEffect } from 'react';
import axios from '../api/axios';

export const PostContext = createContext();

export const PostProvider = ({ children }) => {
  const [posts, setPosts] = useState([]);

  const fetchPosts = async () => {
    try {
      const res = await axios.get('/posts');
      setPosts(res.data.data);
    } catch (err) {
      console.error('게시글 불러오기 실패:', err);
    }
  };

  const getPost = async (id) => {
    const res = await axios.get(`/posts/${id}`);
    return res.data;
  };

  const createPost = async (data) => {
    const res = await axios.post('/posts', data);
    fetchPosts();
    return res.data;
  };

  const updatePost = async (id, data) => {
    await axios.put(`/posts/${id}`, data);
    fetchPosts();
  };

  const deletePost = async (id) => {
    await axios.delete(`/posts/${id}`);
    fetchPosts();
  };

  const toggleLike = async (id) => {
  try {
    const res = await axios.post(`/posts/${id}/like`);
    // 서버 응답: { liked: true/false, likes: number }
    const updated = posts.map((post) =>
      post.id === id ? { ...post, likes: res.data.likes } : post
    );
    setPosts(updated);
    return res.data; // liked, likes 사용 가능
  } catch (err) {
    console.error('좋아요 처리 실패:', err);
  }
};



  return (
    <PostContext.Provider
      value={{
        posts,
        fetchPosts,
        getPost,
        createPost,
        updatePost,
        deletePost,
        toggleLike,
      }}
    >
      {children}
    </PostContext.Provider>
  );
};