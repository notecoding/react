const pool = require('../config/db');

// 댓글 추가
exports.addComment = async (req, res) => {
  const { postId } = req.params;
  const { content } = req.body;
  const { id: author_id, username: author } = req.user;

  try {
    await pool.query(
      'INSERT INTO comments (post_id, author, author_id, content) VALUES (?, ?, ?, ?)',
      [postId, author, author_id, content]
    );
    res.status(201).json({ message: '댓글 추가됨' });
  } catch (err) {
    res.status(500).json({ message: '댓글 추가 실패', error: err.message });
  }
};

// 게시글에 달린 댓글 목록
exports.getCommentsByPostId = async (req, res) => {
  const { postId } = req.params;
  try {
    const [rows] = await pool.query(
      'SELECT * FROM comments WHERE post_id = ? ORDER BY created_at ASC',
      [postId]
    );
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ message: '댓글 목록 조회 실패' });
  }
};

// 댓글 수정
exports.updateComment = async (req, res) => {
  const { commentId } = req.params;
  const { content } = req.body;
  const userId = req.user.id;

  try {
    const [rows] = await pool.query('SELECT * FROM comments WHERE id = ?', [commentId]);
    if (!rows.length) return res.status(404).json({ message: '댓글 없음' });
    if (rows[0].author_id !== userId) return res.status(403).json({ message: '본인만 수정 가능' });

    await pool.query(
      'UPDATE comments SET content = ?, updated_at = NOW() WHERE id = ?',
      [content, commentId]
    );
    res.json({ message: '댓글 수정 완료' });
  } catch (err) {
    res.status(500).json({ message: '댓글 수정 실패' });
  }
};

// 댓글 삭제
exports.deleteComment = async (req, res) => {
  const { commentId } = req.params;
  const userId = req.user.id;

  try {
    const [rows] = await pool.query('SELECT * FROM comments WHERE id = ?', [commentId]);
    if (!rows.length) return res.status(404).json({ message: '댓글 없음' });
    if (rows[0].author_id !== userId) return res.status(403).json({ message: '본인만 삭제 가능' });

    await pool.query('DELETE FROM comments WHERE id = ?', [commentId]);
    res.json({ message: '댓글 삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '댓글 삭제 실패' });
  }
};
