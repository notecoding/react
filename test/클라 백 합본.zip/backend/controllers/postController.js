const pool = require('../config/db');

// 📥 게시글 생성
exports.createPost = async (req, res) => {
  const { category, title, content } = req.body;
  const author = req.user.username;
  const authorId = req.user.id;

  try {
    const [result] = await pool.query(
      `INSERT INTO posts (category, title, content, author, author_id) VALUES (?, ?, ?, ?, ?)`,
      [category, title, content, author, authorId]
    );

    res.status(201).json({ id: result.insertId, message: '게시글 등록 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 생성 실패', error: err.message });
  }
};

// 📚 전체 게시글 조회
exports.getAllPosts = async (req, res) => {
  try {
    const [rows] = await pool.query(`SELECT * FROM posts ORDER BY created_at DESC`);
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ message: '게시글 목록 불러오기 실패' });
  }
};

// 🔍 단일 게시글 조회
exports.getPostById = async (req, res) => {
  const { id } = req.params;
  try {
    const [rows] = await pool.query(`SELECT * FROM posts WHERE id = ?`, [id]);
    if (rows.length === 0) return res.status(404).json({ message: '게시글 없음' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: '게시글 조회 실패' });
  }
};

// ✏️ 게시글 수정
exports.updatePost = async (req, res) => {
  const { id } = req.params;
  const { category, title, content } = req.body;
  const authorId = req.user.id;

  try {
    const [rows] = await pool.query(`SELECT * FROM posts WHERE id = ?`, [id]);
    if (!rows.length) return res.status(404).json({ message: '게시글 없음' });
    if (rows[0].author_id !== authorId) return res.status(403).json({ message: '작성자만 수정 가능' });

    await pool.query(
      `UPDATE posts SET category = ?, title = ?, content = ?, updated_at = NOW() WHERE id = ?`,
      [category, title, content, id]
    );

    res.json({ message: '게시글 수정 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 수정 실패' });
  }
};

// 🗑 게시글 삭제
exports.deletePost = async (req, res) => {
  const { id } = req.params;
  const authorId = req.user.id;

  try {
    const [rows] = await pool.query(`SELECT * FROM posts WHERE id = ?`, [id]);
    if (!rows.length) return res.status(404).json({ message: '게시글 없음' });
    if (rows[0].author_id !== authorId) return res.status(403).json({ message: '작성자만 삭제 가능' });

    await pool.query(`DELETE FROM posts WHERE id = ?`, [id]);
    res.json({ message: '삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '게시글 삭제 실패' });
  }
};

// ❤️ 좋아요 증가
exports.likePost = async (req, res) => {
  const { id } = req.params;

  try {
    await pool.query(`UPDATE posts SET likes = likes + 1 WHERE id = ?`, [id]);
    res.json({ message: '좋아요 반영됨' });
  } catch (err) {
    res.status(500).json({ message: '좋아요 실패' });
  }
};
