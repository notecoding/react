const pool = require('../config/db');

// 전체 카테고리 조회
exports.getCategories = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories ORDER BY `order` ASC');
    res.json({ data: rows });
  } catch (err) {
    res.status(500).json({ message: '카테고리 목록 조회 실패' });
  }
};

// 카테고리 추가
exports.createCategory = async (req, res) => {
  const { name } = req.body;

  try {
    const [existing] = await pool.query('SELECT * FROM categories WHERE name = ?', [name]);
    if (existing.length > 0) return res.status(400).json({ message: '이미 존재하는 카테고리입니다.' });

    const [max] = await pool.query('SELECT MAX(`order`) AS maxOrder FROM categories');
    const newOrder = (max[0].maxOrder || 0) + 1;

    await pool.query('INSERT INTO categories (name, `order`) VALUES (?, ?)', [name, newOrder]);
    res.status(201).json({ message: '카테고리 추가 완료' });
  } catch (err) {
    res.status(500).json({ message: '카테고리 추가 실패' });
  }
};

// 카테고리 수정
exports.updateCategory = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;

  try {
    const [existing] = await pool.query('SELECT * FROM categories WHERE name = ? AND id != ?', [name, id]);
    if (existing.length > 0) return res.status(400).json({ message: '이미 존재하는 이름입니다.' });

    await pool.query('UPDATE categories SET name = ? WHERE id = ?', [name, id]);
    res.json({ message: '카테고리 수정 완료' });
  } catch (err) {
    res.status(500).json({ message: '카테고리 수정 실패' });
  }
};

// 카테고리 삭제
exports.deleteCategory = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM categories WHERE id = ?', [id]);
    res.json({ message: '삭제 완료' });
  } catch (err) {
    res.status(500).json({ message: '삭제 실패' });
  }
};

// 카테고리 순서 변경
exports.reorderCategory = async (req, res) => {
  const { draggedId, newOrder } = req.body;
  try {
    const [categories] = await pool.query('SELECT * FROM categories ORDER BY `order` ASC');
    const reordered = [];

    const dragged = categories.find(cat => cat.id === draggedId);
    if (!dragged) return res.status(400).json({ message: '드래그된 카테고리 없음' });

    // 드래그된 항목 제거
    const withoutDragged = categories.filter(cat => cat.id !== draggedId);
    withoutDragged.splice(newOrder - 1, 0, dragged);

    // 새로운 순서대로 업데이트
    for (let i = 0; i < withoutDragged.length; i++) {
      reordered.push(pool.query('UPDATE categories SET `order` = ? WHERE id = ?', [i + 1, withoutDragged[i].id]));
    }

    await Promise.all(reordered);
    res.json({ message: '카테고리 순서 변경 완료' });
  } catch (err) {
    res.status(500).json({ message: '순서 변경 실패' });
  }
};
