const express = require('express');
const router = express.Router();
const {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  reorderCategory
} = require('../controllers/categoryController');

const verifyToken = require('../middleware/authMiddleware');

router.get('/', getCategories);
router.post('/', verifyToken, createCategory);
router.put('/:id', verifyToken, updateCategory);
router.delete('/:id', verifyToken, deleteCategory);
router.post('/reorder', verifyToken, reorderCategory);

module.exports = router;
