// 📁 src/pages/Profile.jsx

import React, { useContext, useEffect, useState } from 'react';
import '../../styles/Profile.css';
import { AuthContext } from '../../context/AuthContext';
import { PostContext } from '../../context/PostContext';
import axios from '../../api/axios';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const { user, logout } = useContext(AuthContext);
  const { posts } = useContext(PostContext);
  const navigate = useNavigate();

  const [tab, setTab] = useState('posts');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [message, setMessage] = useState({ type: '', text: '' });

  const myPosts = posts.filter((post) => post.author_id === user?.id);

  const handleChangePassword = async () => {
    setMessage({ type: '', text: '' });

    if (!password || !confirm) {
      return setMessage({ type: 'error', text: '모든 필드를 입력해주세요.' });
    }

    if (password !== confirm) {
      return setMessage({ type: 'error', text: '비밀번호가 일치하지 않습니다.' });
    }

    try {
      await axios.put('/auth/change-password', { password });
      setMessage({ type: 'success', text: '비밀번호 변경 완료!' });
      setPassword('');
      setConfirm('');
    } catch (err) {
      setMessage({ type: 'error', text: err.response?.data?.message || '오류 발생' });
    }
  };

  const handleDeleteAccount = async () => {
    if (!window.confirm('정말 계정을 삭제하시겠습니까?')) return;

    try {
      await axios.delete('/auth/delete');
      logout();
      alert('회원 탈퇴가 완료되었습니다.');
      navigate('/');
    } catch (err) {
      alert('탈퇴 실패: ' + err.response?.data?.message);
    }
  };

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h2>프로필 관리</h2>
        <div className="profile-tabs">
          <button className={`tab ${tab === 'posts' ? 'active' : ''}`} onClick={() => setTab('posts')}>
            내 글 보기
          </button>
          <button className={`tab ${tab === 'password' ? 'active' : ''}`} onClick={() => setTab('password')}>
            비밀번호 변경
          </button>
          <button className={`tab ${tab === 'delete' ? 'active' : ''}`} onClick={() => setTab('delete')}>
            회원 탈퇴
          </button>
        </div>
      </div>

      {tab === 'posts' && (
        <div className="posts-tab">
          <h3>내가 작성한 게시글</h3>
          <div className="user-posts">
            {myPosts.length === 0 ? (
              <div className="no-posts">작성한 게시글이 없습니다.</div>
            ) : (
              myPosts.map((post) => (
                <div
                  key={post.id}
                  className="post-item"
                  onClick={() => navigate(`/post/${post.id}`)}
                >
                  <div className="post-category">{post.category}</div>
                  <div className="post-title">{post.title}</div>
                  <div className="post-meta">
                    <span>{new Date(post.created_at).toLocaleDateString()}</span>
                    <span>❤️ {post.likes}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {tab === 'password' && (
        <div className="password-tab">
          <h3>비밀번호 변경</h3>
          {message.text && (
            <div className={message.type === 'error' ? 'error-message' : 'success-message'}>
              {message.text}
            </div>
          )}
          <div className="password-form">
            <div className="form-group">
              <label>새 비밀번호</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="새 비밀번호 입력"
              />
            </div>
            <div className="form-group">
              <label>비밀번호 확인</label>
              <input
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="비밀번호 다시 입력"
              />
            </div>
            <button className="update-btn" onClick={handleChangePassword}>
              변경하기
            </button>
          </div>
        </div>
      )}

      {tab === 'delete' && (
        <div className="delete-tab">
          <h3>회원 탈퇴</h3>
          <div className="delete-warning">
            정말 탈퇴하시겠습니까? 작성한 글과 댓글은 복구되지 않습니다.
          </div>
          <button className="delete-btn" onClick={handleDeleteAccount}>
            회원 탈퇴하기
          </button>
        </div>
      )}
    </div>
  );
};

export default Profile;
