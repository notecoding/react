// 📁 src/pages/MainBoard.jsx

import React, { useContext, useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PostContext } from '../../context/PostContext';
import { CategoryContext } from '../../context/CategoryContext';
import '../../styles/MainBoard.css';

const MainBoard = () => {
  const { posts, toggleLike, fetchPosts } = useContext(PostContext);
  const { categories } = useContext(CategoryContext);
  const { categoryName } = useParams();

  const [filtered, setFiltered] = useState([]);

  // 카테고리 필터링
  useEffect(() => {
    if (categoryName && categoryName !== 'all') {
      const decoded = decodeURIComponent(categoryName);
      setFiltered(posts.filter((post) => post.category === decoded));
    } else {
      setFiltered(posts);
    }
  }, [posts, categoryName]);

  useEffect(() => {
    fetchPosts();
  }, []);

  return (
    <div className="main-container">
      {/* 🟦 배너 */}
      <div className="banner">✨ 오늘의 게시판에 오신 것을 환영합니다 ✨</div>

      {/* 📦 게시판 컨테이너 */}
      <div className="board-container">
        {/* 🧭 헤더 영역 */}
        <div className="board-header">
          <h2 className="board-title">{categoryName === 'all' ? '전체 게시판' : decodeURIComponent(categoryName)}</h2>

          <div className="category-filter">
            <Link to="/board/all" className={`category-btn ${categoryName === 'all' ? 'active' : ''}`}>
              전체
            </Link>
            {categories.map((cat) => (
              <Link
                key={cat.id}
                to={`/board/${encodeURIComponent(cat.name)}`}
                className={`category-btn ${decodeURIComponent(categoryName) === cat.name ? 'active' : ''}`}
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>

        {/* 📄 게시글 목록 */}
        {filtered.length === 0 ? (
          <div className="no-posts">게시글이 없습니다.</div>
        ) : (
          filtered.map((post) => (
            <Link to={`/post/${post.id}`} key={post.id} className="post-link">
              <div className="card">
                <div className="category">{post.category}</div>
                <div className="title">{post.title}</div>
                <div className="content-preview">{post.content.slice(0, 80)}...</div>
                <div className="meta">
                  <span>작성자: {post.author}</span>
                  <span>{new Date(post.created_at).toLocaleDateString()}</span>
                  <button
                    className="like-btn"
                    onClick={(e) => {
                      e.preventDefault();
                      toggleLike(post.id);
                    }}
                  >
                    ❤️ {post.likes}
                  </button>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
};

export default MainBoard;
