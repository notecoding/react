// 📁 src/pages/PostDetail.jsx

import React, { useContext, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import axios from '../../api/axios';
import { AuthContext } from '../../context/AuthContext';
import { PostContext } from '../../context/PostContext';
import '../../styles/PostDetail.css';

const PostDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const { getPost, toggleLike, deletePost } = useContext(PostContext);

  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchAll = async () => {
    const data = await getPost(id);
    setPost(data);
    await fetchComments();
    setLoading(false);
  };

  const fetchComments = async () => {
    const res = await axios.get(`/comments/${id}`);
    setComments(res.data.data);
  };

  const handleAddComment = async () => {
    if (!user) return alert('로그인 후 작성 가능합니다.');
    if (!newComment.trim()) return;

    await axios.post(`/comments/${id}`, { content: newComment });
    setNewComment('');
    fetchComments();
  };

  const handleEditComment = async (commentId) => {
    if (!editContent.trim()) return;
    await axios.put(`/comments/${commentId}`, { content: editContent });
    setEditingId(null);
    fetchComments();
  };

  const handleDeleteComment = async (commentId) => {
    if (window.confirm('정말 삭제하시겠습니까?')) {
      await axios.delete(`/comments/${commentId}`);
      fetchComments();
    }
  };

  const handleDeletePost = async () => {
    if (window.confirm('게시글을 삭제하시겠습니까?')) {
      await deletePost(post.id);
      navigate('/');
    }
  };

  useEffect(() => {
    fetchAll();
    // eslint-disable-next-line
  }, [id]);

  if (loading) return <div className="loading-container">불러오는 중...</div>;
  if (!post) return <div className="loading-container">게시글이 없습니다.</div>;

  return (
    <div className="post-detail-container">
      <div className="post-header">
        <div className="category">{post.category}</div>
        <div className="title">{post.title}</div>
        <div className="post-meta">
          <span>작성자: {post.author}</span>
          <span>{new Date(post.created_at).toLocaleString()}</span>
        </div>
      </div>

      <div className="post-content">
        {post.content.split('\n').map((line, idx) => (
          <p key={idx}>{line}</p>
        ))}
      </div>

      <div className="post-actions">
        <button className="like-btn" onClick={() => toggleLike(post.id)}>
          ❤️ {post.likes}
        </button>

        {user?.id === post.author_id && (
          <div className="author-actions">
            <Link to={`/edit/${post.id}`} className="edit-btn">수정</Link>
            <button onClick={handleDeletePost} className="delete-btn">삭제</button>
          </div>
        )}
      </div>

      <div className="comments-section">
        <h3>댓글</h3>

        {/* 댓글 작성 */}
        <div className="comment-form">
          <textarea
            placeholder="댓글을 입력하세요"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
          />
          <button onClick={handleAddComment} disabled={!newComment.trim()}>
            등록
          </button>
        </div>

        {/* 댓글 목록 */}
        <div className="comments-list">
          {comments.length === 0 ? (
            <div className="no-comments">등록된 댓글이 없습니다.</div>
          ) : (
            comments.map((c) => (
              <div key={c.id} className="comment">
                <div className="comment-meta">
                  <span className="comment-author">{c.author}</span>
                  <div className="comment-date-actions">
                    <span className="comment-date">
                      {new Date(c.created_at).toLocaleString()}
                    </span>
                    {user?.id === c.author_id && (
                      <div className="comment-actions">
                        <button
                          className="comment-edit-btn"
                          onClick={() => {
                            setEditingId(c.id);
                            setEditContent(c.content);
                          }}
                        >
                          수정
                        </button>
                        <button
                          className="comment-delete-btn"
                          onClick={() => handleDeleteComment(c.id)}
                        >
                          삭제
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {editingId === c.id ? (
                  <div className="comment-edit-form">
                    <textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                    />
                    <div className="comment-edit-actions">
                      <button
                        className="comment-save-btn"
                        onClick={() => handleEditComment(c.id)}
                      >
                        저장
                      </button>
                      <button
                        className="comment-cancel-btn"
                        onClick={() => setEditingId(null)}
                      >
                        취소
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="comment-content">{c.content}</div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default PostDetail;
