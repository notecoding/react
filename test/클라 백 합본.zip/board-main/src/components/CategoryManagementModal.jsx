// 📁 src/components/CategoryManagementModal.jsx

import React, { useContext, useEffect, useState } from 'react';
import '../../styles/Modal.css';
import { CategoryContext } from '../../context/CategoryContext';

const CategoryManagementModal = ({ onClose }) => {
  const {
    categories,
    createCategory,
    updateCategory,
    deleteCategory,
    reorderCategories,
    fetchCategories
  } = useContext(CategoryContext);

  const [newCategory, setNewCategory] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editedName, setEditedName] = useState('');
  const [draggingId, setDraggingId] = useState(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleCreate = async () => {
    if (!newCategory.trim()) return;
    await createCategory({ name: newCategory.trim() });
    setNewCategory('');
  };

  const handleUpdate = async (id) => {
    if (!editedName.trim()) return;
    await updateCategory(id, { name: editedName.trim() });
    setEditingId(null);
  };

  const handleDelete = async (id) => {
    if (window.confirm('정말 삭제하시겠습니까?')) {
      await deleteCategory(id);
    }
  };

  const handleDragStart = (id) => {
    setDraggingId(id);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = async (targetId) => {
    if (draggingId === null || draggingId === targetId) return;

    const targetIndex = categories.findIndex((c) => c.id === targetId);
    await reorderCategories(draggingId, targetIndex + 1); // order는 1부터 시작
    setDraggingId(null);
  };

  return (
    <div className="modal">
      <div className="modal-content category-modal">
        <h3>카테고리 관리</h3>

        {/* ➕ 추가 */}
        <div className="category-form">
          <div className="form-group">
            <input
              type="text"
              placeholder="새 카테고리 이름"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
            />
            <button onClick={handleCreate} disabled={!newCategory.trim()}>
              추가
            </button>
          </div>
        </div>

        {/* 📄 리스트 */}
        <div className="category-list">
          <h4>카테고리 목록</h4>
          <ul>
            {categories.length === 0 ? (
              <div className="no-categories">카테고리가 없습니다.</div>
            ) : (
              categories.map((cat) => (
                <li
                  key={cat.id}
                  className="category-item"
                  draggable
                  onDragStart={() => handleDragStart(cat.id)}
                  onDragOver={handleDragOver}
                  onDrop={() => handleDrop(cat.id)}
                >
                  <div className="category-display">
                    {editingId === cat.id ? (
                      <div className="category-edit">
                        <input
                          value={editedName}
                          onChange={(e) => setEditedName(e.target.value)}
                        />
                        <div className="category-actions">
                          <button
                            className="btn-sm btn-save"
                            onClick={() => handleUpdate(cat.id)}
                          >
                            저장
                          </button>
                          <button
                            className="btn-sm btn-cancel"
                            onClick={() => setEditingId(null)}
                          >
                            취소
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <span className="category-name">{cat.name}</span>
                        <div className="category-actions">
                          <button
                            className="btn-sm btn-edit"
                            onClick={() => {
                              setEditingId(cat.id);
                              setEditedName(cat.name);
                            }}
                          >
                            수정
                          </button>
                          <button
                            className="btn-sm btn-delete"
                            onClick={() => handleDelete(cat.id)}
                          >
                            삭제
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>

        <button className="close-btn" onClick={onClose}>닫기</button>
      </div>
    </div>
  );
};

export default CategoryManagementModal;
