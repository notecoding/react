// 📁 src/components/RegisterModal.jsx

import React, { useContext, useState } from 'react';
import '../styles/Modal.css';
import { AuthContext } from '../context/AuthContext';

const RegisterModal = ({ onClose, onSwitchToLogin }) => {
  const { register, loading } = useContext(AuthContext);

  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');

  const handleRegister = async () => {
    setError('');

    if (!name || !username || !password || !confirm) {
      return setError('모든 필드를 입력해주세요.');
    }

    if (password !== confirm) {
      return setError('비밀번호가 일치하지 않습니다.');
    }

    try {
      await register({ name, username, password });
      onSwitchToLogin(); // 회원가입 후 로그인 모달로 전환
    } catch (err) {
      setError('회원가입 실패: 이미 존재하는 아이디일 수 있습니다.');
    }
  };

  return (
    <div className="modal">
      <div className="modal-content auth-modal">
        <h3>회원가입</h3>

        {error && <div className="error-message">{error}</div>}

        <div className="auth-form">
          <div className="form-group">
            <label>이름</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="이름 입력"
            />
          </div>
          <div className="form-group">
            <label>아이디</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="아이디 입력"
            />
          </div>
          <div className="form-group">
            <label>비밀번호</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="비밀번호 입력"
            />
          </div>
          <div className="form-group">
            <label>비밀번호 확인</label>
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="비밀번호 다시 입력"
            />
          </div>
        </div>

        <button
          className="auth-button"
          onClick={handleRegister}
          disabled={!name || !username || !password || !confirm || loading}
        >
          {loading ? '처리 중...' : '회원가입'}
        </button>

        <div className="auth-links">
          이미 계정이 있으신가요?{' '}
          <a onClick={onSwitchToLogin}>로그인</a>
        </div>

        <button className="close-btn" onClick={onClose}>
          닫기
        </button>
      </div>
    </div>
  );
};

export default RegisterModal;
