// 📁 src/components/SearchModal.jsx

import React, { useContext, useEffect, useState } from 'react';
import '../styles/Modal.css';
import { PostContext } from '../context/PostContext';
import { useNavigate } from 'react-router-dom';

const SearchModal = ({ onClose }) => {
  const { posts, fetchPosts } = useContext(PostContext);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const [filtered, setFiltered] = useState([]);

  useEffect(() => {
    fetchPosts(); // 게시글 최신화
  }, []);

  useEffect(() => {
    const q = query.toLowerCase();
    const results = posts.filter((post) => post.title.toLowerCase().includes(q));
    setFiltered(results);
  }, [query, posts]);

  const handleClick = (postId) => {
    onClose();
    navigate(`/post/${postId}`);
  };

  return (
    <div className="modal">
      <div className="modal-content auth-modal">
        <h3>게시글 검색</h3>

        <div className="auth-form">
          <div className="form-group">
            <input
              type="text"
              placeholder="검색어 입력 (제목 기준)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="search-results">
          {query.trim() === '' ? (
            <p>검색어를 입력해주세요.</p>
          ) : filtered.length === 0 ? (
            <p>검색 결과가 없습니다.</p>
          ) : (
            <ul>
              {filtered.map((post) => (
                <li key={post.id} onClick={() => handleClick(post.id)} style={{ cursor: 'pointer', padding: '8px 0', borderBottom: '1px solid #eee' }}>
                  <strong>{post.title}</strong> — {post.category}
                </li>
              ))}
            </ul>
          )}
        </div>

        <button className="close-btn" onClick={onClose}>닫기</button>
      </div>
    </div>
  );
};

export default SearchModal;
