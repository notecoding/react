// 📁 src/components/LoginModal.jsx

import React, { useContext, useState } from 'react';
import '../styles/Modal.css';
import { AuthContext } from '../context/AuthContext';

const LoginModal = ({ onClose, onSwitchToRegister }) => {
  const { login, loading } = useContext(AuthContext);

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setError('');
    try {
      await login({ username, password });
      onClose(); // 로그인 성공 시 모달 닫기
    } catch (err) {
      setError('로그인 실패: 아이디 또는 비밀번호를 확인하세요.');
    }
  };

  return (
    <div className="modal">
      <div className="modal-content auth-modal">
        <h3>로그인</h3>

        {error && <div className="error-message">{error}</div>}

        <div className="auth-form">
          <div className="form-group">
            <label>아이디</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="아이디 입력"
            />
          </div>
          <div className="form-group">
            <label>비밀번호</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="비밀번호 입력"
            />
          </div>
        </div>

        <button
          className="auth-button"
          onClick={handleLogin}
          disabled={!username || !password || loading}
        >
          {loading ? '로딩 중...' : '로그인'}
        </button>

        <div className="auth-links">
          아직 회원이 아니신가요?{' '}
          <a onClick={onSwitchToRegister}>회원가입</a>
        </div>

        <button className="close-btn" onClick={onClose}>
          닫기
        </button>
      </div>
    </div>
  );
};

export default LoginModal;
