import React, { useEffect, useState, useContext } from 'react';
import { PostContext } from '../context/PostContext';
import { Link } from 'react-router-dom';
import '../styles/Home.css';

const Home = () => {
  const { posts, fetchPosts } = useContext(PostContext);
  const [latest, setLatest] = useState([]);
  const [topLiked, setTopLiked] = useState([]);

  useEffect(() => {
    fetchPosts();
  }, []);

  useEffect(() => {
    const sorted = [...posts];
    setLatest(sorted.slice(0, 5));
    setTopLiked(sorted.sort((a, b) => b.likes - a.likes).slice(0, 5));
  }, [posts]);

  return (
    <div className="home-container">
      <section>
        <h2>🆕 최신 게시글</h2>
        <ul className="post-preview-list">
          {latest.map((post) => (
            <li key={post.id} className="post-preview">
              <Link to={`/post/${post.id}`}>
                <strong>{post.title}</strong> — {post.author}
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2>🔥 인기 게시글</h2>
        <ul className="post-preview-list">
          {topLiked.map((post) => (
            <li key={post.id} className="post-preview">
              <Link to={`/post/${post.id}`}>
                <strong>{post.title}</strong> ❤️ {post.likes}
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default Home;
